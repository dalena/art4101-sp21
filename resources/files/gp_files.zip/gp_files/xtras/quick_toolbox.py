bl_info = {
    "name": "Quick Toolbox",
    "author": "MeBMan",
    "description": "A toolbox for easy brush and tools switching",
    "blender": (2, 80, 0),
    "version": (1,0,4,1),
    "location": "View3D",
    "warning": "",
    "category": "Object",
}

import bpy
import json
import string
from bpy.types import Menu, Operator, PropertyGroup, UIList, Panel, AddonPreferences
from bpy.props import (
    EnumProperty,
    StringProperty,
    PointerProperty,
    IntProperty,
    BoolProperty,
    CollectionProperty
)
from bl_ui.space_toolsystem_common import ToolSelectPanelHelper
from bpy_extras.io_utils import ImportHelper
from bl_ui.properties_paint_common import (
    UnifiedPaintPanel,
    brush_settings,
    brush_basic_texpaint_settings,
    brush_texture_settings,
)
from bpy.app.translations import contexts as i18n_contexts
import nodeitems_utils


def _indented_layout(layout, level):
    indentpx = 16
    if level == 0:
        level = 0.0001   # Tweak so that a percentage of 0 won't split by half
    indent = level * indentpx / bpy.context.region.width

    split = layout.split(factor=indent)
    col = split.column()
    col = split.column()
    return col

####Letter Update if clicked again#####
def update_letter(self,context):
    brush_letters = context.scene.brush_letters
    if self.letter == brush_letters.old_letter:
        brush_letters.letter = 'ALL'
        brush_letters.old_letter = 'ALL'
    else:
        brush_letters.old_letter = self.letter


def bs_header_button(self,context):
    self.layout.operator(
        "bs.show_toolbox",
        text='Toolbox',
        icon='BRUSHES_ALL'
    )

    
def update_toolbox_button(self,context):
    addon_prefs = context.preferences.addons[__name__].preferences
    if addon_prefs.show_toolbox_button:
        bpy.types.VIEW3D_HT_header.append(bs_header_button)
        bpy.types.IMAGE_HT_header.append(bs_header_button)
        bpy.types.NODE_HT_header.append(bs_header_button)
        bpy.types.SEQUENCER_HT_header.append(bs_header_button)
    else:
        bpy.types.VIEW3D_HT_header.remove(bs_header_button)
        bpy.types.IMAGE_HT_header.remove(bs_header_button)
        bpy.types.NODE_HT_header.remove(bs_header_button)
        bpy.types.SEQUENCER_HT_header.remove(bs_header_button)
        
addon_keymaps = []
def add_hotkey(self,context):
    user_preferences = context.preferences
    addon_prefs = user_preferences.addons[__name__].preferences
    
    wm = context.window_manager
    kc = wm.keyconfigs.addon
     
    for km, kmi, kmk in addon_keymaps:
        km.keymap_items.remove(kmi)
        km.keymap_items.remove(kmk)
    addon_keymaps.clear()
    
    if kc:
        km = kc.keymaps.new(name="Window")
        kmi= km.keymap_items.new(
            "wm.call_menu", type=addon_prefs.fav_type, value=addon_prefs.fav_value, alt=addon_prefs.fav_alt,
                shift=addon_prefs.fav_shift, ctrl=addon_prefs.fav_ctrl, repeat=addon_prefs.fav_repeat
        )
        kmi.properties.name='TOOLBOX_MT_show_fav'
        kmk = km.keymap_items.new(
            "bs.show_toolbox", type=addon_prefs.keymap_type, value=addon_prefs.keymap_value, alt=addon_prefs.keymap_alt,
                shift=addon_prefs.keymap_shift, ctrl=addon_prefs.keymap_ctrl, repeat=addon_prefs.keymap_repeat
        )
       
        addon_keymaps.append((km, kmi,kmk))

def draw_kmi(kmi, layout, level):
    map_type = kmi.map_type

    col = _indented_layout(layout, level)

    if kmi.show_expanded:
        col = col.column(align=True)
        box = col.box()
    else:
        box = col.column()

    split = box.split()

    # header bar
    row = split.row(align=True)
    row.prop(kmi, "show_expanded", text="", emboss=False)
    row.prop(kmi, "active", text="", emboss=False)


    row.label(text=kmi.name)

    row = split.row()
    row.prop(kmi, "map_type", text="")
    if map_type == 'KEYBOARD':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'MOUSE':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'NDOF':
        row.prop(kmi, "type", text="", full_event=True)
    elif map_type == 'TWEAK':
        subrow = row.row()
        subrow.prop(kmi, "type", text="")
        subrow.prop(kmi, "value", text="")
    elif map_type == 'TIMER':
        row.prop(kmi, "type", text="")
    else:
        row.label()

    if (not kmi.is_user_defined) and kmi.is_user_modified:
        row.operator("preferences.keyitem_restore", text="", icon='BACK').item_id = kmi.id
    else:
        row.operator("preferences.keyitem_remove", text="", icon='X').item_id = kmi.id

    # Expanded, additional event settings
    if kmi.show_expanded:
        box = col.box()

        split = box.split(factor=0.4)
        sub = split.row()

        # One day...
        # sub.prop_search(kmi, "idname", bpy.context.window_manager, "operators_all", text="")
        sub.prop(kmi, "idname", text="")

        if map_type not in {'TEXTINPUT', 'TIMER'}:
            sub = split.column()
            subrow = sub.row(align=True)

            if map_type == 'KEYBOARD':
                subrow.prop(kmi, "type", text="", event=True)
                subrow.prop(kmi, "value", text="")
                subrow_repeat = subrow.row(align=True)
                subrow_repeat.active = kmi.value in {'ANY', 'PRESS'}
                subrow_repeat.prop(kmi, "repeat", text="Repeat")
            elif map_type in {'MOUSE', 'NDOF'}:
                subrow.prop(kmi, "type", text="")
                subrow.prop(kmi, "value", text="")

            subrow = sub.row()
            subrow.scale_x = 0.75
            subrow.prop(kmi, "any", toggle=True)
            subrow.prop(kmi, "shift", toggle=True)
            subrow.prop(kmi, "ctrl", toggle=True)
            subrow.prop(kmi, "alt", toggle=True)
            subrow.prop(kmi, "oskey", text="Cmd", toggle=True)
            subrow.prop(kmi, "key_modifier", text="", event=True)

        # Operator properties
        box.template_keymap_item_properties(kmi)

              

class BrushLetters(PropertyGroup):

    letter: bpy.props.EnumProperty(
        items=[
#            ("FAV", "      ", "Favourites", "FUND", 0),
            ("PRESETS", "    ", "All Brush Presets", "BRUSHES_ALL", 0),
            ("ALL", "All", "All", "", 1),
            ("A", "A", "A", "", 2),
            ("B", "B", "B", "", 3),
            ("C", "C", "C", "", 4),
            ("D", "D", "D", "", 5),
            ("E", "E", "E", "", 6),
            ("F", "F", "F", "", 7),
            ("G", "G", "G", "", 8),
            ("H", "H", "H", "", 9),
            ("I", "I", "I", "", 10),
            ("J", "J", "J", "", 11),
            ("K", "K", "K", "", 12),
            ("L", "L", "L", "", 13),
            ("M", "M", "M", "", 14),
            ("N", "N", "N", "", 15),
            ("O", "O", "O", "", 16),
            ("P", "P", "P", "", 17),
            ("Q", "Q", "Q", "", 18),
            ("R", "R", "R", "", 19),
            ("S", "S", "S", "", 20),
            ("T", "T", "T", "", 21),
            ("U", "U", "U", "", 22),
            ("V", "V", "V", "", 23),
            ("W", "W", "W", "", 24),
            ("X", "X", "X", "", 25),
            ("Y", "Y", "Y", "", 26),
            ("Z", "Z", "Z", "", 27),
            
        ],
        default="ALL",
        update=update_letter
    )
    
    old_letter: StringProperty(
        name='Old letter',
        default=''
    )
    
    
    
    
class Favourites(PropertyGroup):
    label: StringProperty(
        name="Label",
        default="",
    )
    idname: StringProperty(
        name="idname",
        default="",
    )
    icon_value: IntProperty(
        name="Icon value",
        default=0,
    )
    index: IntProperty(
        name='index',
        default=0
    )
    is_preset: BoolProperty(
        name='Is preset',
        default=False
    )



def draw_gpencil_layer_active(context, layout):
    gpl = context.active_gpencil_layer
    if gpl:
        layout.label(text="Active Layer")
        row = layout.row(align=True)
        row.operator_context = 'EXEC_REGION_WIN'
        row.operator_menu_enum("gpencil.layer_change", "layer", text="", icon='GREASEPENCIL')
        row.prop(gpl, "info", text="")
        row.operator("gpencil.layer_remove", text="", icon='X')


def draw_gpencil_material_active(context, layout):
    ob = context.active_object
    if ob and len(ob.material_slots) > 0 and ob.active_material_index >= 0:
        ma = ob.material_slots[ob.active_material_index].material
        if ma:
            layout.label(text="Active Material")
            row = layout.row(align=True)
            row.operator_context = 'EXEC_REGION_WIN'
            row.operator_menu_enum("gpencil.material_set", "slot", text="", icon='MATERIAL')
            row.prop(ma, "name", text="")



class BS_OT_show_brushes(Operator):
    # label is displayed at the center of the pie menu.
    bl_idname = "bs.show_toolbox"
    bl_label = "Toolbox"
    bl_description = "Show toolbox"
    bl_options = {'REGISTER'}

    
    @classmethod
    def poll(self, context):
        space_type=context.space_data.type
        clsic = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
        if clsic == None:
            return False
        if space_type=='SEQUENCE_EDITOR':
            return False
        return True
    @staticmethod
    def draw_active_tool_header(
            context, layout,
            *,
            show_tool_name=False,
            tool_key=None,
    ):
        if tool_key is None:
            space_type, mode = ToolSelectPanelHelper._tool_key_from_context(context)
        else:
            space_type, mode = tool_key

        if space_type is None:
            return None

        cls = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
        item, tool, icon_value = cls._tool_get_active(context, space_type, mode, with_icon=True)
        if item is None:
            return None

        draw_settings = item.draw_settings
        if draw_settings is not None:
            draw_settings(context, layout, tool)

        idname_fallback = tool.idname_fallback
        if idname_fallback and idname_fallback != item.idname:
            tool_settings = context.tool_settings

            # Show popover which looks like an enum but isn't one.
            if tool_settings.workspace_tool_type == 'FALLBACK':
                tool_fallback_id = cls.tool_fallback_id
                item, _select_index = cls._tool_get_by_id_active(context, tool_fallback_id)
                label = item.label
            else:
                label = "Active Tool"


        return tool
    
    
    def draw(self, context):
        
#        letters=['A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z']
#        
        space_type=context.space_data.type
        clsic = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
        
        addon_prefs = context.preferences.addons[__name__].preferences
        
        layout = self.layout
        is_valid_context=None
        
        #####Context menu defs#########
        def tool_menu(r):
            row=r.column()
            tool_mode = context.mode  
            tool = self.draw_active_tool_header(
                context, row,show_tool_name=True,
                tool_key=(space_type, tool_mode),
            )
            row.separator()
            
            draw_fn = getattr(_draw_tool_settings_context_mode, tool_mode, None)
            if draw_fn is not None:
                is_valid_context = draw_fn(context, row, tool)
            
#            nodeitems_utils.draw_node_categories_menu(self, context)
        ######################
       
        #######Topbar########
        def draw_mode_settings(n):
            if space_type == 'VIEW_3D':
                tool_mode = context.mode
                mode_string = context.mode

                def row_for_mirror():
                    row = n.row(align=True)
                    row.label(icon='MOD_MIRROR')
                    sub = row.row(align=True)
                    sub.alignment='LEFT'
                    sub.scale_x = 0.6
                    return row, sub

                if mode_string == 'EDIT_MESH':
                    _row, sub = row_for_mirror()
                    sub.prop(context.object.data, "use_mirror_x", text="X", toggle=True)
                    sub.prop(context.object.data, "use_mirror_y", text="Y", toggle=True)
                    sub.prop(context.object.data, "use_mirror_z", text="Z", toggle=True)
#                    tool_settings = context.tool_settings
#                    layout.prop(tool_settings, "use_mesh_automerge", text="")
                elif mode_string == 'EDIT_ARMATURE':
                    _row, sub = row_for_mirror()
                    sub.prop(context.object.data, "use_mirror_x", text="X", toggle=True)
                elif mode_string == 'POSE':
                    _row, sub = row_for_mirror()
                    sub.prop(context.object.pose, "use_mirror_x", text="X", toggle=True)
                elif mode_string == 'PAINT_WEIGHT':
                    row, sub = row_for_mirror()
                    wpaint = context.tool_settings.weight_paint
                    sub.prop(wpaint, "use_symmetry_x", text="X", toggle=True)
                    sub.prop(wpaint, "use_symmetry_y", text="Y", toggle=True)
                    sub.prop(wpaint, "use_symmetry_z", text="Z", toggle=True)
#                    row.popover(panel="VIEW3D_PT_tools_weightpaint_symmetry_for_topbar", text="")
                elif mode_string == 'SCULPT':
                    row, sub = row_for_mirror()
                    if bpy.app.version >= (2,91,0):
                        ob_data = context.object.data
                        sub.prop(ob_data, "use_mirror_x", text="X", toggle=True)
                        sub.prop(ob_data, "use_mirror_y", text="Y", toggle=True)
                        sub.prop(ob_data, "use_mirror_z", text="Z", toggle=True)
                    else:
                        sculpt = context.tool_settings.sculpt
                        sub.prop(sculpt, "use_symmetry_x", text="X", toggle=True)
                        sub.prop(sculpt, "use_symmetry_y", text="Y", toggle=True)
                        sub.prop(sculpt, "use_symmetry_z", text="Z", toggle=True)
#                    row.popover(panel="VIEW3D_PT_sculpt_symmetry_for_topbar", text="")
                elif mode_string == 'PAINT_TEXTURE':
                    _row, sub = row_for_mirror()
                    ipaint = context.tool_settings.image_paint
                    sub.prop(ipaint, "use_symmetry_x", text="X", toggle=True)
                    sub.prop(ipaint, "use_symmetry_y", text="Y", toggle=True)
                    sub.prop(ipaint, "use_symmetry_z", text="Z", toggle=True)
                    # No need for a popover, the panel only has these options.
                elif mode_string == 'PAINT_VERTEX':
                    row, sub = row_for_mirror()
                    vpaint = context.tool_settings.vertex_paint
                    sub.prop(vpaint, "use_symmetry_x", text="X", toggle=True)
                    sub.prop(vpaint, "use_symmetry_y", text="Y", toggle=True)
                    sub.prop(vpaint, "use_symmetry_z", text="Z", toggle=True)
#                    row.popover(panel="VIEW3D_PT_tools_vertexpaint_symmetry_for_topbar", text="")
                if mode_string == 'EDIT_MESH':
                    tool_settings = context.tool_settings
                    sub.prop(tool_settings, "use_mesh_automerge", text="Automerge")
                elif mode_string == 'PAINT_WEIGHT':
                    sub.operator('wm.call_panel',text='  ', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_weightpaint_symmetry_for_topbar'
                elif mode_string == 'SCULPT':
                    sub.operator('wm.call_panel',text='  ', icon='DOWNARROW_HLT').name='VIEW3D_PT_sculpt_symmetry_for_topbar'
                elif mode_string == 'PAINT_VERTEX':
                    sub.operator('wm.call_panel',text='  ', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_vertexpaint_symmetry_for_topbar'

                # Expand panels from the side-bar as popovers.
#                popover_kw = {"space_type": 'VIEW_3D', "region_type": 'UI', "category": "Tool"}
                row=n.row()
                row.alignment='LEFT'

                if mode_string == 'SCULPT':
                    row.template_header_3D_mode()
                    sub=row.row(align=True)
                    sub.alignment='LEFT'
                    sub.operator(
                        "sculpt.dynamic_topology_toggle",
                        icon='CHECKBOX_HLT' if context.sculpt_object.use_dynamic_topology_sculpting else 'CHECKBOX_DEHLT',
                        text="",
                    )
                    sub.operator('wm.call_panel',text='Dyntopo').name='VIEW3D_PT_sculpt_dyntopo'
                    row.operator('wm.call_panel',text='Remesh',icon='DOWNARROW_HLT').name='VIEW3D_PT_sculpt_voxel_remesh'
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_sculpt_options'
                elif mode_string == 'PAINT_VERTEX':
                    row.template_header_3D_mode()
                elif mode_string == 'PAINT_WEIGHT':
                    row.template_header_3D_mode()
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_weightpaint_options'
                elif mode_string == 'PAINT_TEXTURE':
                    row.template_header_3D_mode()
                    row.operator('wm.call_panel',text='Texture slots', icon='DOWNARROW_HLT').name='VIEW3D_PT_slots_projectpaint'
                    row.operator('wm.call_panel',text='Mask', icon='DOWNARROW_HLT').name='VIEW3D_PT_mask'
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_imagepaint_options'
                elif mode_string == 'EDIT_TEXT':
                    row.template_header_3D_mode()
                    row.popover_group(context=".text_edit", **popover_kw)
                elif mode_string == 'EDIT_ARMATURE':
                    row.template_header_3D_mode()
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_armatureedit_options'
#                elif mode_string == 'EDIT_METABALL':
#                    row.popover_group(context=".mball_edit", **popover_kw)
#                elif mode_string == 'EDIT_LATTICE':
#                    row.popover_group(context=".lattice_edit", **popover_kw)
#                elif mode_string == 'EDIT_CURVE':
#                    row.popover_group(context=".curve_edit", **popover_kw)
                elif mode_string == 'EDIT_MESH':
                    row.template_header_3D_mode()
                elif mode_string == 'POSE':
                    row.template_header_3D_mode()
                    row.operator('wm.call_panel',text='Pose options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_posemode_options'
                elif mode_string == 'PARTICLE':
                    row.template_header_3D_mode()
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_particlemode_options'
                elif mode_string == 'OBJECT':
                    row.operator('wm.call_panel',text='Options', icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_object_options'
                elif mode_string in {'PAINT_GPENCIL', 'EDIT_GPENCIL', 'SCULPT_GPENCIL', 'WEIGHT_GPENCIL'}:
                    row.template_header_3D_mode()
                    tool_settings = context.tool_settings
                    obj=context.object
                    if obj and obj.type == 'GPENCIL' and context.gpencil_data:
                        gpd = context.gpencil_data

                        if gpd.is_stroke_paint_mode:
                            sub = row.row(align=True)
                            sub.prop(tool_settings, "use_gpencil_draw_onback", text="", icon='MOD_OPACITY')
                            sub.separator(factor=0.4)
                            sub.prop(tool_settings, "use_gpencil_weight_data_add", text="", icon='WPAINT_HLT')
                            sub.separator(factor=0.4)
                            sub.prop(tool_settings, "use_gpencil_draw_additive", text="", icon='FREEZE')

                        # Select mode for Editing
                        if gpd.use_stroke_edit_mode:
                            row.prop(tool_settings, "gpencil_selectmode_edit", text="", expand=True)

                        # Select mode for Sculpt
                        if gpd.is_stroke_sculpt_mode:
                            sub=row.row(align=True)
                            sub.prop(tool_settings, "use_gpencil_select_mask_point", text="")
                            sub.prop(tool_settings, "use_gpencil_select_mask_stroke", text="")
                            sub.prop(tool_settings, "use_gpencil_select_mask_segment", text="")

                        # Select mode for Vertex Paint
                        if gpd.is_stroke_vertex_mode:
                            sub=row.row(align=True)
                            sub.prop(tool_settings, "use_gpencil_vertex_select_mask_point", text="")
                            sub.prop(tool_settings, "use_gpencil_vertex_select_mask_stroke", text="")
                            sub.prop(tool_settings, "use_gpencil_vertex_select_mask_segment", text="")

                        if (
                                gpd.use_stroke_edit_mode or
                                gpd.is_stroke_sculpt_mode or
                                gpd.is_stroke_weight_mode or
                                gpd.is_stroke_vertex_mode
                        ):
                            
                            row.prop(gpd, "use_multiedit", text="", icon='GP_MULTIFRAME_EDITING')

                            sub = row.row(align=True)
                            sub.alignment='LEFT'
                            sub.active = gpd.use_multiedit
                            sub.operator('wm.call_panel',text='Multiframe',icon='DOWNARROW_HLT').name='VIEW3D_PT_gpencil_multi_frame'

                        if gpd.use_stroke_edit_mode:
                            row.operator('wm.call_panel',text='Interpolate',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_interpolate'
                            
                
                def draw_3d_brush_settings(layout, tool_mode):
                    if addon_prefs.show_all_brush_settings is False:
                        row.operator('wm.call_panel',text='Brush',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_brush_settings_advanced'
#                    if tool_mode != 'PAINT_WEIGHT':
#                        row.operator('wm.call_panel',text='Texture',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_brush_texture'
                        
                    if tool_mode == 'PAINT_TEXTURE':
                        row.operator('wm.call_panel',text='Mask Texture',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_mask_texture'
                    row.operator('wm.call_panel',text='Stroke',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_brush_stroke'
                    row.operator('wm.call_panel',text='Falloff',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_brush_falloff'
#                    row.operator('wm.call_panel',text='Cursor',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_brush_display'

                # Note: general mode options should be added to 'draw_mode_settings'.
                if addon_prefs.show_extra_menus:
                    is_valid=True
                    if tool_mode == 'SCULPT':
                        if is_valid:
                            draw_3d_brush_settings(layout, tool_mode)
                    elif tool_mode == 'PAINT_VERTEX':
                        if is_valid:
                            draw_3d_brush_settings(layout, tool_mode)
                    elif tool_mode == 'PAINT_WEIGHT':
                        if is_valid:
                            draw_3d_brush_settings(layout, tool_mode)
                    elif tool_mode == 'PAINT_TEXTURE':
                        if is_valid:
                            draw_3d_brush_settings(layout, tool_mode)
                    elif tool_mode == 'EDIT_ARMATURE':
                        pass
                    elif tool_mode == 'EDIT_CURVE':
                        pass
                    elif tool_mode == 'EDIT_MESH':
                        pass
                    elif tool_mode == 'POSE':
                        pass
                    elif tool_mode == 'PARTICLE':
                        # Disable, only shows "Brush" panel, which is already in the top-bar.
                        # if tool.has_datablock:
                        #     layout.popover_group(context=".paint_common", **popover_kw)
                        pass
                    elif tool_mode == 'PAINT_GPENCIL':
                        if is_valid:
                            brush = context.tool_settings.gpencil_paint.brush
                            if brush.gpencil_tool != 'ERASE':
                                if brush.gpencil_tool != 'TINT':
                                    if addon_prefs.show_all_brush_settings is False:
                                        row.operator('wm.call_panel',text='Brush',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_brush_advanced'
                                if brush.gpencil_tool not in {'FILL', 'TINT'}:
                                    row.operator('wm.call_panel',text='Stroke',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_brush_stroke'

    #                            row.operator('wm.call_panel',text='Cursor',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_paint_appearance'
                    elif tool_mode == 'SCULPT_GPENCIL':
                        if is_valid:
                            brush = context.tool_settings.gpencil_sculpt_paint.brush
                            tool = brush.gpencil_tool
                            if tool in {'SMOOTH', 'RANDOMIZE'}:
                                row.operator('wm.call_panel',text='Options',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_sculpt_options'
                            row.operator('wm.call_panel',text='Cursor',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_sculpt_appearance'
                    elif tool_mode == 'WEIGHT_GPENCIL':
                        if is_valid:
                            row.operator('wm.call_panel',text='Cursor',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_weight_appearance'
                    elif tool_mode == 'VERTEX_GPENCIL':
                        if is_valid:
                            row.operator('wm.call_panel',text='Cursor',icon='DOWNARROW_HLT').name='VIEW3D_PT_tools_grease_pencil_vertex_appearance'
        #####################
        ############XFORM TEMPLATE#############
        def draw_xform_template(layout):
            if space_type=='VIEW_3D':
                obj = context.active_object
                object_mode = 'OBJECT' if obj is None else obj.mode
                has_pose_mode = (
                    (object_mode == 'POSE') or
                    (object_mode == 'WEIGHT_PAINT' and context.pose_object is not None)
                )

                tool_settings = context.tool_settings

                # Mode & Transform Settings
                scene = context.scene

                # Orientation
                if object_mode in {'OBJECT', 'EDIT', 'EDIT_GPENCIL'} or has_pose_mode:
                    orient_slot = scene.transform_orientation_slots[0]
                    row = layout.row(align=True)

                    sub = row.row()
                    sub.ui_units_x = 4
                    sub.operator('wm.call_panel',text=orient_slot.type.title(), icon='ORIENTATION_'+orient_slot.type).name='VIEW3D_PT_transform_orientations'
                    
                # Pivot
                if object_mode in {'OBJECT', 'EDIT', 'EDIT_GPENCIL', 'SCULPT_GPENCIL'} or has_pose_mode:
                    layout.prop(tool_settings, "transform_pivot_point", text="", icon_only=True)

                # Snap
                show_snap = False
                if obj is None:
                    show_snap = True
                else:
                    if (object_mode not in {
                            'SCULPT', 'VERTEX_PAINT', 'WEIGHT_PAINT', 'TEXTURE_PAINT',
                            'PAINT_GPENCIL', 'SCULPT_GPENCIL', 'WEIGHT_GPENCIL', 'VERTEX_GPENCIL'
                    }) or has_pose_mode:
                        show_snap = True
                    else:

                        paint_settings = UnifiedPaintPanel.paint_settings(context)

                        if paint_settings:
                            brush = paint_settings.brush
                            if brush and hasattr(brush, "stroke_method") and brush.stroke_method == 'CURVE':
                                show_snap = True

                if show_snap:
                    snap_items = bpy.types.ToolSettings.bl_rna.properties["snap_elements"].enum_items
                    snap_elements = tool_settings.snap_elements
                    if len(snap_elements) == 1:
                        text = ""
                        for elem in snap_elements:
                            icon = snap_items[elem].icon
                            break
                    else:
                        text = "Mix"
                        icon = 'NONE'
                    del snap_items, snap_elements

                    row = layout.row(align=True)
                    row.prop(tool_settings, "use_snap", text="")

                    sub = row.row(align=True)
                    sub.operator('wm.call_panel',text=text,icon=icon).name='VIEW3D_PT_snapping'

                # Proportional editing
                if object_mode in {'EDIT', 'PARTICLE_EDIT', 'SCULPT_GPENCIL', 'EDIT_GPENCIL', 'OBJECT'}:
                    row = layout.row(align=True)
                    kw = {}
                    if object_mode == 'OBJECT':
                        attr = "use_proportional_edit_objects"
                    else:
                        attr = "use_proportional_edit"

                        if tool_settings.use_proportional_edit:
                            if tool_settings.use_proportional_connected:
                                kw["icon"] = 'PROP_CON'
                            elif tool_settings.use_proportional_projected:
                                kw["icon"] = 'PROP_PROJECTED'
                            else:
                                kw["icon"] = 'PROP_ON'
                        else:
                            kw["icon"] = 'PROP_OFF'

                    row.prop(tool_settings, attr, icon_only=True, **kw)
                    sub = row.row(align=True)
                    sub.active = getattr(tool_settings, attr)
                    sub.operator('wm.call_panel',text='',icon=tool_settings.proportional_edit_falloff+'CURVE').name='VIEW3D_PT_proportional_edit'
                
        #######################################
        
        rim = layout.row()
        split=rim
        if ((addon_prefs.toolbox_width > 500)and( context.window.width > 500)):
            if addon_prefs.show_topbar_menus:
                split=rim.split(factor=0.9)
                r=split.row()
                r.alignment='LEFT'
                if addon_prefs.show_searchbar:
                    r.template_menu_search()
                draw_mode_settings(r)
                draw_xform_template(r)
        else:
            if addon_prefs.show_topbar_menus:
                split=rim.split(factor=0.9)
                r=split.row()
                r.alignment='LEFT'
                if addon_prefs.show_searchbar:
                    r.template_menu_search()
                draw_mode_settings(r)
                draw_xform_template(r)
#        sculpt_context_menu(r)
        row=split.row(align=True)
        row.alignment='RIGHT'
        if ((addon_prefs.show_ui_buttons is True)and(addon_prefs.toolbox_width > 500)and( context.window.width > 500)):
            if ((space_type=='VIEW_3D')and(context.mode=='PAINT_GPENCIL')):
                row.prop(addon_prefs,'show_pallete' ,text='', icon='COLOR' )
            
            row.prop(addon_prefs, 'show_fav_icon', text='', icon='HEART',toggle=True)
            row.prop(addon_prefs, 'show_global_favs', text='', icon='WORLD_DATA',toggle=True)
            row.prop(addon_prefs, 'show_presets', text='', icon='BRUSHES_ALL',toggle=True)
        row.operator('bs.show_settings', text='', icon='SETTINGS' )
        
        column_num = addon_prefs.fav_column_num
        if context.window.width <  400:
            column_num=2

        grid = layout.grid_flow(row_major=True,columns=column_num,align=True)
        grid.scale_y=1.3
        
        
        
        space_type = context.space_data.type
        tool_active_id = getattr(
            ToolSelectPanelHelper._tool_active_from_context(context, space_type),
            "idname", None,
        )
        
        
        
            
        
        ####fAV TOOLBAR#######
        
        for item_group in clsic.tools_from_context(context):
            is_active=False
            if type(item_group) is tuple:
                index_current = clsic._tool_group_active.get(item_group[0].idname, 0)
                for sub_item in item_group:
                    ###Global fav#####
                    if addon_prefs.show_global_favs:
                        for m in addon_prefs.global_favs:
                            if sub_item.idname == m.idname:
                                is_active=(sub_item.idname == tool_active_id)
                                icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                                r=grid.row(align=True)
                                r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                                if addon_prefs.show_fav_icon:
                                    fav=r.operator('bs.delete_fav', text='', icon='FUND',depress=is_active)
                                    fav.global_index = m.index
                                    fav.local_index = 0
                                    fav.global_faved=True
                                    fav.local_faved=False
                    ####local fav####               
                    for m in context.scene.favit:
                        if sub_item.idname == m.idname:
                            is_active=(sub_item.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                            r=grid.row(align=True)
                            r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                            if addon_prefs.show_fav_icon:
                                fav=r.operator('bs.delete_fav', text='', icon='FUND',depress=is_active)
                                fav.global_index = 0
                                fav.local_index = m.index
                                fav.global_faved=False
                                fav.local_faved=True
            else:
                if item_group is not None:
                    ####global fav######
                    if addon_prefs.show_global_favs:
                        for m in addon_prefs.global_favs:
                            if item_group.idname == m.idname:
                                is_active=(item_group.idname == tool_active_id)
                                icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                                r=grid.row(align=True)
                                r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     
                                if addon_prefs.show_fav_icon:
                                    fav=r.operator('bs.delete_fav', text='', icon='FUND',depress=is_active)
                                    fav.global_index = m.index
                                    fav.local_index = 0
                                    fav.global_faved=True
                                    fav.local_faved=False
                    #####local fav######      
                    for m in context.scene.favit:
                        if item_group.idname == m.idname:
                            is_active=(item_group.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                            r=grid.row(align=True)
                            r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     
                            if addon_prefs.show_fav_icon:
                                fav=r.operator('bs.delete_fav', text='', icon='FUND',depress=is_active)
                                fav.global_index = 0
                                fav.local_index = m.index
                                fav.global_faved=False
                                fav.local_faved=True
        if space_type == 'VIEW_3D':
            if addon_prefs.show_presets:
                def preset_favs(mode):
                    if brush.name == m.label:
                        icon_value= m.icon_value
                        r=grid.row(align=True)
                        r.operator('bs.set_brush', text=brush.name.title(), icon_value=icon_value).brush_name=m.label
                        if addon_prefs.show_fav_icon:
                            if mode=='GLOBAL':
                                fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                fav.local_index = 0
                                fav.global_index = m.index
                                fav.global_faved = True
                                fav.local_faved = False
                            else:
                                fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                fav.local_index = m.index
                                fav.global_index = 0
                                fav.global_faved = False
                                fav.local_faved = True
                ####Global fav#####
                if addon_prefs.show_global_favs: 
                    for m in addon_prefs.global_favs:
                        try:
                            if m.is_preset:
                                if m.label in bpy.data.brushes:
                                    brush = bpy.data.brushes[m.label]
                                    if brush.name == m.label:
                                        icon_value= brush.preview.icon_id
                                        if context.mode == 'SCULPT':
                                            if brush.use_paint_sculpt:
                                                preset_favs('GLOBAL')
                                        elif context.mode == 'PAINT_VERTEX':
                                            if brush.use_paint_vertex:
                                                preset_favs('GLOBAL')
                                        elif context.mode == 'PAINT_WEIGHT':
                                            if brush.use_paint_weight:
                                                preset_favs('GLOBAL')
                                        elif context.mode == 'PAINT_TEXTURE':
                                            if brush.use_paint_image:
                                                preset_favs('GLOBAL')
                                        elif context.mode == 'PAINT_GPENCIL':
                                            if brush.use_paint_grease_pencil:
                                                preset_favs('GLOBAL')
                                        elif context.mode == 'VERTEX_GPENCIL':
                                            if brush.use_vertex_grease_pencil:
                                                preset_favs('GLOBAL')
                                else:
                                    
                                    icon_value= m.icon_value
                                    r=grid.row(align=True)
                                    r.operator('bs.disabled', text=m.label, icon_value=icon_value)
                                    if context.scene.brush_letters.show_fav_icon:
                                        r.enabled=True
                                        fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                        fav.local_index = 0
                                        fav.global_index = m.index
                                        fav.global_faved = True
                                        fav.local_faved = False
                        except:
                            pass
                #####local fav#####
                for m in context.scene.favit:
                    try:
                        if m.is_preset:
                            for brush in bpy.data.brushes:
                                if brush.name == m.label:
                                    icon_value= brush.preview.icon_id
                                    if context.mode == 'SCULPT':
                                        if brush.use_paint_sculpt:
                                            preset_favs('LOCAL')
                                    elif context.mode == 'PAINT_VERTEX':
                                        if brush.use_paint_vertex:
                                            preset_favs('LOCAL')
                                    elif context.mode == 'PAINT_WEIGHT':
                                        if brush.use_paint_weight:
                                            preset_favs('LOCAL')
                                    elif context.mode == 'PAINT_TEXTURE':
                                        if brush.use_paint_image:
                                            preset_favs('LOCAL')
                                    elif context.mode == 'PAINT_GPENCIL':
                                        if brush.use_paint_grease_pencil:
                                            preset_favs('LOCAL')
                                    elif context.mode == 'VERTEX_GPENCIL':
                                        if brush.use_vertex_grease_pencil:
                                            preset_favs('LOCAL')
                    except:
                        pass
                    
        ######Fav toolbar end#####
        split=layout
        if ((addon_prefs.toolbox_width > 500)and( context.window.width > 500)):
            if addon_prefs.show_sidebar:
                split=layout.split(factor=0.2)
                row=split.row()
                
        #        sculpt_context_menu(row)
                if space_type != 'IMAGE_EDITOR':
                    tool_menu(row)
        #        gpencil_draw_context_menu(row)
        else:
            if addon_prefs.show_sidebar:
                split=layout.split(factor=0.35)
                row=split.row()
                
        #        sculpt_context_menu(row)
                if space_type != 'IMAGE_EDITOR':
                    tool_menu(row)
        #        gpencil_draw_context_menu(row)
        if space_type =='IMAGE_EDITOR':
                split=layout
                
        row=split.row()
        c=row.column()
        r=c.row(align=True)
        if addon_prefs.show_alphabet_filter_menu:
            if ((addon_prefs.toolbox_width < 400)or(context.window.width < 400)):
                
                r.prop(context.scene.brush_letters, "letter", text='Filter',expand=False)
            else:
                r.prop(context.scene.brush_letters, "letter", expand=True)
        
        
        col_num = addon_prefs.column_num
        if context.window.width <  400:
            col_num=2
        grid = c.grid_flow(columns=col_num,align=True)
        grid.scale_y=1.3
        grid_preset = c.grid_flow(columns=col_num,align=True)
        grid_preset.scale_y=1.3
        
        
        def layo():
            alphabet_string= string.ascii_uppercase
            alphabet_list=list(alphabet_string)
            
            for letter in alphabet_list:
                if letter==context.scene.brush_letters.letter:
                    for item_group in clsic.tools_from_context(context):
                        is_active=False
                        if type(item_group) is tuple:
                            index_current = clsic._tool_group_active.get(item_group[0].idname, 0)
                            for sub_item in item_group:
                                if sub_item.label.startswith(letter):
                                    is_active=(sub_item.idname == tool_active_id)
                                    icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                                    r=grid.row(align=True)
                                    r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                                    if addon_prefs.show_fav_icon:
                                        local_faved=False
                                        global_faved=False
                                        local_index=0
                                        global_index=0
                                        for m in context.scene.favit:
                                            if sub_item.idname == m.idname:
                                                local_faved=True
                                                local_index=m.index
                                                break
                                        for m in addon_prefs.global_favs:
                                            if sub_item.idname == m.idname:
                                                global_faved=True
                                                global_index=m.index
                                                break
                                        if ((local_faved)or(global_faved)):
                                            fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                            fav.local_index = local_index
                                            fav.global_index = global_index
                                            fav.local_faved=local_faved
                                            fav.global_faved=global_faved
                                        else:
                                            fav=r.operator('bs.add_fav', text='', icon='HEART')
                                            fav.label=sub_item.label
                                            fav.idname=sub_item.idname
                                            fav.icon_value=icon_value
                                            fav.is_preset=False
                        else:
                            if item_group is not None:
                                if item_group.label.startswith(letter):
                                    is_active=(item_group.idname == tool_active_id)
                                    icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                                    r=grid.row(align=True)
                                    r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     
                                    if addon_prefs.show_fav_icon:
                                        local_faved=False
                                        global_faved=False
                                        local_index=0
                                        global_index=0
                                        for m in context.scene.favit:
                                            if item_group.idname == m.idname:
                                                local_faved=True
                                                local_index=m.index
                                                break
                                        for m in addon_prefs.global_favs:
                                            if item_group.idname == m.idname:
                                                global_faved=True
                                                global_index=m.index
                                                break
                                                
                                        if ((local_faved)or(global_faved)):
                                            fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                            fav.local_index = local_index
                                            fav.global_index = global_index
                                            fav.local_faved=local_faved
                                            fav.global_faved=global_faved
                                        else:
                                            fav = r.operator('bs.add_fav', text='', icon='HEART',depress=is_active)
                                            fav.label=item_group.label
                                            fav.idname=item_group.idname
                                            fav.icon_value=icon_value
                                            fav.is_preset=False
                                            
                    if space_type == 'VIEW_3D':
                        def brush_func():
                            icon_value= brush.preview.icon_id
                            r=grid_preset.row(align=True)
                            r.operator("bs.set_brush", text=brush_name.title(), icon_value=icon_value).brush_name=brush.name     
                            if addon_prefs.show_fav_icon:
                                local_faved=False
                                global_faved=False
                                local_index=0
                                global_index=0
                                for m in context.scene.favit:
                                    try:
                                        if m.is_preset:
                                            if brush.name == m.label:
                                                local_faved=True
                                                local_index=m.index
                                                break
                                    except:
                                        pass
                                for m in addon_prefs.global_favs:
                                    try:
                                        if m.is_preset:
                                            if brush.name == m.label:
                                                global_faved=True
                                                global_index=m.index
                                                break
                                    except:
                                        pass
                                        
                                if ((local_faved)or(global_faved)):
                                    fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                    fav.local_index = local_index
                                    fav.global_index = global_index
                                    fav.local_faved=local_faved
                                    fav.global_faved=global_faved
                                else:
                                    fav = r.operator('bs.add_fav', text='', icon='HEART')
                                    fav.label=brush.name
                                    fav.idname=""
                                    fav.icon_value=brush.preview.icon_id
                                    fav.is_preset=True
                        
                        if addon_prefs.show_presets:
                            for brush in bpy.data.brushes:
                                brush_name = brush.name
                                if brush.name.startswith(letter):
                                    if context.mode == 'SCULPT':
                                        if brush.use_paint_sculpt:
                                            brush_func()
                                    elif context.mode == 'PAINT_VERTEX':
                                        if brush.use_paint_vertex:
                                            brush_func()
                                    elif context.mode == 'PAINT_WEIGHT':
                                        if brush.use_paint_weight:
                                            brush_func()
                                    elif context.mode == 'PAINT_TEXTURE':
                                        if brush.use_paint_image:
                                            brush_func()
                                    elif context.mode == 'PAINT_GPENCIL':
                                        if brush.use_paint_grease_pencil:
                                            brush_func()
                                    elif context.mode == 'VERTEX_GPENCIL':
                                        if brush.use_vertex_grease_pencil:
                                            brush_func()
                                      
        if context.scene.brush_letters.letter == 'ALL':
            is_active=False
            for item_group in clsic.tools_from_context(context):
                if type(item_group) is tuple:
                    index_current = clsic._tool_group_active.get(item_group[0].idname, 0)
                    for sub_item in item_group:
                        is_active=(sub_item.idname == tool_active_id)
                        icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                        
                        r=grid.row(align=True)
                        r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                        if addon_prefs.show_fav_icon:
                            local_faved=False
                            global_faved=False
                            local_index=0
                            global_index=0
                            for m in context.scene.favit:
                                if sub_item.idname == m.idname:
                                    local_faved=True
                                    local_index=m.index
                                    break
                            for m in addon_prefs.global_favs:
                                if sub_item.idname == m.idname:
                                    global_faved=True
                                    global_index=m.index
                                    break
                            if ((local_faved)or(global_faved)):
                                fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                fav.local_index = local_index
                                fav.global_index = global_index
                                fav.local_faved=local_faved
                                fav.global_faved=global_faved
                            else:
                                fav=r.operator('bs.add_fav', text='', icon='HEART',depress=is_active)
                                fav.label=sub_item.label
                                fav.idname=sub_item.idname
                                fav.icon_value=icon_value
                                fav.is_preset=False
                else:
                    if item_group is not None:
                        is_active=(item_group.idname == tool_active_id)
                        icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                        r=grid.row(align=True)
                        r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     
                        if addon_prefs.show_fav_icon:
                            local_faved=False
                            global_faved=False
                            local_index=0
                            global_index=0
                            for m in context.scene.favit:
                                if item_group.idname == m.idname:
                                    local_faved=True
                                    local_index=m.index
                                    break
                            for m in addon_prefs.global_favs:
                                if item_group.idname == m.idname:
                                    global_faved=True
                                    global_index=m.index
                                    break
                                    
                            if ((local_faved)or(global_faved)):
                                fav=r.operator('bs.delete_fav', text='', icon='FUND')
                                fav.local_index = local_index
                                fav.global_index =global_index
                                fav.local_faved=local_faved
                                fav.global_faved=global_faved
                            else:
                                fav = r.operator('bs.add_fav', text='', icon='HEART',depress=is_active)
                                fav.label=item_group.label
                                fav.idname=item_group.idname
                                fav.icon_value=icon_value
                                fav.is_preset=False
            
            if space_type == 'VIEW_3D':                    
                def brush_func():
                    icon_value= brush.preview.icon_id
                    r=grid_preset.row(align=True)
                    r.operator("bs.set_brush", text=brush_name.title(), icon_value=icon_value).brush_name=brush.name     
                    if addon_prefs.show_fav_icon:
                        local_faved=False
                        global_faved=False
                        local_index=0
                        global_index=0
                        for m in context.scene.favit:
                            try:
                                if m.is_preset:
                                    if brush.name == m.label:
                                        local_faved=True
                                        local_index=m.index
                                        break
                            except:
                                pass
                        for m in addon_prefs.global_favs:
                            try:
                                if m.is_preset:
                                    if brush.name == m.label:
                                        global_faved=True
                                        global_index=m.index
                                        break
                            except:
                                pass
                                
                        if ((local_faved)or(global_faved)):
                            fav=r.operator('bs.delete_fav', text='', icon='FUND')
                            fav.local_index = local_index
                            fav.global_index = global_index
                            fav.local_faved=local_faved
                            fav.global_faved=global_faved
                        else:
                            fav = r.operator('bs.add_fav', text='', icon='HEART')
                            fav.label=brush.name
                            fav.idname=""
                            fav.icon_value=brush.preview.icon_id
                            fav.is_preset=True
                
                if addon_prefs.show_presets:
                    try:
                        for brush in bpy.data.brushes:
                            brush_name = brush.name
                            if context.mode == 'SCULPT':
                                if brush.use_paint_sculpt:
                                    brush_func()
                            elif context.mode == 'PAINT_VERTEX':
                                if brush.use_paint_vertex:
                                    brush_func()
                            elif context.mode == 'PAINT_WEIGHT':
                                if brush.use_paint_weight:
                                    brush_func()
                            elif context.mode == 'PAINT_TEXTURE':
                                if brush.use_paint_image:
                                    brush_func()
                            elif context.mode == 'PAINT_GPENCIL':
                                if brush.use_paint_grease_pencil:
                                    brush_func()
                            elif context.mode == 'VERTEX_GPENCIL':
                                if brush.use_vertex_grease_pencil:
                                    brush_func()
                                            
                    except:
                        pass
                                    
        elif context.scene.brush_letters.letter == 'PRESETS':
            if space_type == 'VIEW_3D':
                def brush_func():
                    icon_value= brush.preview.icon_id
                    r=grid.row(align=True)
                    r.operator("bs.set_brush", text=brush_name.title(), icon_value=icon_value).brush_name=brush.name     
                    if addon_prefs.show_fav_icon:
                        local_faved=False
                        global_faved=False
                        local_index=0
                        global_index=0
                        for m in context.scene.favit:
                            try:
                                if m.is_preset:
                                    if brush.name == m.label:
                                        local_faved=True
                                        local_index=m.index
                                        break
                            except:
                                pass
                        for m in addon_prefs.global_favs:
                            try:
                                if m.is_preset:
                                    if brush.name == m.label:
                                        global_faved=True
                                        global_index=m.index
                                        break
                            except:
                                pass
                                
                        if ((local_faved) or (global_faved)):
                            fav=r.operator('bs.delete_fav', text='', icon='FUND')
                            fav.local_index = local_index
                            fav.global_index = global_index
                            fav.local_faved=local_faved
                            fav.global_faved=global_faved
                        else:
                            fav = r.operator('bs.add_fav', text='', icon='HEART')
                            fav.label=brush.name
                            fav.idname=""
                            fav.icon_value=brush.preview.icon_id
                            fav.is_preset=True
                
                for brush in bpy.data.brushes:
                    brush_name = brush.name
                    if context.mode == 'SCULPT':
                        if brush.use_paint_sculpt:
                            brush_func()
                    elif context.mode == 'PAINT_VERTEX':
                        if brush.use_paint_vertex:
                            brush_func()
                    elif context.mode == 'PAINT_WEIGHT':
                        if brush.use_paint_weight:
                            brush_func()
                    elif context.mode == 'PAINT_TEXTURE':
                        if brush.use_paint_image:
                            brush_func()
                    elif context.mode == 'PAINT_GPENCIL':
                        if brush.use_paint_grease_pencil:
                            brush_func()
                    elif context.mode == 'VERTEX_GPENCIL':
                        if brush.use_vertex_grease_pencil:
                            brush_func()
        else:
            layo()
            
    
    def invoke(self, context, event):
        region= context.region
        addon_prefs = context.preferences.addons[__name__].preferences
        extra=50
        
        if addon_prefs.fixed_toolbox:
            
            if addon_prefs.toolbox_pos == 'TL':
                cx=context.area.x + extra
                cy=((context.area.y + context.area.height)-extra)
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'BL':
                cx=context.area.x + extra
                cy=context.area.y +extra
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'TR':
                cx=((context.area.x + context.area.width)- extra)
                cy=((context.area.y + context.area.height)-extra)
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'BR':
                cx=((context.area.x + context.area.width)- extra)
                cy=context.area.y +extra
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'C':
                cx=0
                if context.area.width/2 < addon_prefs.toolbox_width/2:
                    cx=(context.area.x + context.area.width/5)
                else:
                    cx=(context.area.x + ((context.area.width/2)-(addon_prefs.toolbox_width/2)))
                cy=(context.area.y + ((context.area.height/2)+(context.area.height/5)))
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'CU':
                cx=(context.area.x + (context.area.width/2))
                cy=((context.area.y + context.area.height)-extra)
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'CD':
                cx=(context.area.x + (context.area.width/2))
                cy=context.area.y +extra
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'CL':
                cx=context.area.x + extra
                cy=(context.area.y + (context.area.height/2))
                context.window.cursor_warp(cx, cy)
            elif addon_prefs.toolbox_pos == 'CR':
                cx=cx=((context.area.x + context.area.width)- extra)
                cy=(context.area.y + (context.area.height/2))
                context.window.cursor_warp(cx, cy)
                
        width=addon_prefs.toolbox_width
        if context.window.width < 500:
            width=context.window.width - 30
        return context.window_manager.invoke_popup(self, width=width)
        
    def execute(self, context):
        return {'FINISHED'}

class BS_OT_SetBrush(Operator):
    bl_idname = "bs.set_brush"
    bl_label = "Set Brush"
    bl_description = "Set brush"
    
    brush_name: StringProperty()
    
    def execute(self,context):
        D = bpy.data
        bpy.ops.wm.tool_set_by_id(name="builtin_brush.Draw")
        ts = context.tool_settings
        if context.mode == 'SCULPT':
            ts.sculpt.brush= D.brushes[self.brush_name]
        elif context.mode == 'PAINT_ VERTEX':
            ts.vertex_paint.brush= D.brushes[self.brush_name]
        elif context.mode == 'PAINT_WEIGHT':
            ts.weight_paint.brush= D.brushes[self.brush_name]
        elif context.mode == 'PAINT_TEXTURE':
            ts.image_paint.brush= D.brushes[self.brush_name]
        elif context.mode == 'PAINT_GPENCIL':
            ts.gpencil_paint.brush= D.brushes[self.brush_name]
        elif context.mode == 'VERTEX_GPENCIL':
            ts.gpencil_vertex_paint.brush= D.brushes[self.brush_name]
    
        return {'FINISHED'}

class BS_OT_ShowSettings(Operator):
    bl_idname = "bs.show_settings"
    bl_label = "Show Settings"
    bl_description = "Settings of the Toolbox"
    bl_options={'REGISTER'}
    
    def draw(self,context):
        layout = self.layout
        layout.label(text="Settings")
        
        addon_prefs = context.preferences.addons[__name__].preferences
        

        box = layout.box()
        col = box.column(align=True)
        col.label(text='Favourites settings')
        col.prop(addon_prefs, 'save_fav_globally')
        r=col.row(align=True)
        r.operator('bs.clear_fav', text='Clear Global Favourites').type='GLOBAL'
        r.operator('bs.clear_fav', text='Clear Local Favourites').type='LOCAL'
        r=col.row(align=True)
        r.operator('bs.export_fav', text='Export Favourites', icon='EXPORT' )
        r.operator('bs.import_fav', text='Import favourites', icon='IMPORT' )
        
        box = layout.box()
        col = box.column(align=True)
        col.label(text='UI settings')
        col.prop(addon_prefs, 'column_num')
        col.prop(addon_prefs, 'fav_column_num')
        col.prop(addon_prefs, 'fav_menu_column')
        col.prop(addon_prefs, 'toolbox_width')
        col.prop(context.preferences.view, "color_picker_type")
#        col.prop(addon_prefs, 'show_toolbox_button')
        col.prop(addon_prefs, 'show_fav_icon')
        col.prop(addon_prefs, 'show_presets')
        col.prop(addon_prefs, 'show_global_favs')
        col.prop(addon_prefs, 'show_pallete')
        col.prop(addon_prefs, 'show_sidebar')
        col.prop(addon_prefs, 'show_all_brush_settings')
        col.prop(addon_prefs, 'show_topbar_menus')
        col.prop(addon_prefs, 'show_extra_menus')
        col.prop(addon_prefs, 'show_alphabet_filter_menu')
        col.prop(addon_prefs, 'show_ui_buttons')
        if addon_prefs.show_topbar_menus:
            col.prop(addon_prefs, 'show_searchbar')
        col.prop(addon_prefs, 'fixed_toolbox')
        if addon_prefs.fixed_toolbox:
            def depressed(let):
                dep = False
                if addon_prefs.toolbox_pos == let:
                    dep = True
                else:
                    dep = False
                return dep
           
            b = col.box()
            ro=b.row()
            ro.label(text='Toolbox Position: ')
            c=ro.column(align=True)
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('TL')).pos='TL'
            rowi.operator('bs.change_pos', text='', icon='TRIA_UP', depress=depressed('CU')).pos='CU'
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('TR')).pos='TR'
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='TRIA_LEFT', depress=depressed('CL')).pos='CL'
            rowi.operator('bs.change_pos', text='', icon='RADIOBUT_ON', depress=depressed('C')).pos='C'
            rowi.operator('bs.change_pos', text='', icon='TRIA_RIGHT', depress=depressed('CR')).pos='CR'
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('BL')).pos='BL'
            rowi.operator('bs.change_pos', text='', icon='TRIA_DOWN', depress=depressed('CD')).pos='CD'
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('BR')).pos='BR'
        
        box = layout.box()
        col = box.column()
        kc = context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items['bs.show_toolbox']
        km=None
        for c in context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items:
            try:
                if c.properties.name=='TOOLBOX_MT_show_fav':
                    km=c
            except:
                pass
        kc = context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items['bs.show_toolbox']
        draw_kmi(kc, col,0)
        draw_kmi(km, col,0)
        
    def invoke(self, context, event):
        return context.window_manager.invoke_popup(self, width=400)
        
    def execute(self, context):
        return {'FINISHED'}
    
class BS_UL_FavList(UIList):
    def draw_item(
        self, context, layout, data, item, icon, active_data, active_propname, index
    ):
        custom_icon = item.icon_value
        base = item.label

        if self.layout_type in {"DEFAULT", "COMPACT"}:
            row= layout.row()
            row.label(text='',icon_value=custom_icon)
            row.label(text=base)
            row.operator('bs.delete_fav', text='', icon='X').index=index
            

        elif self.layout_type in {"GRID"}:
            layout.alignment = "CENTER"
            layout.label(text="", icon_value=custom_icon)
        

class BS_OT_AddFav(Operator):
    bl_idname = "bs.add_fav"
    bl_label = "Add to Favourite"
    bl_description = "Add brush to favorites"

    label: StringProperty(
        name='Name'
    )
    idname: StringProperty(
        name='idname'
    )
    icon_value: IntProperty(
        name='iconvalue'
    )
    is_preset: BoolProperty(
        name='Is preset',
        default=False
    )


    def execute(self, context):
        scene = context.scene
        addon_prefs = context.preferences.addons[__name__].preferences
        if addon_prefs.save_fav_globally:
            Fav = addon_prefs.global_favs.add()
            Fav.label = self.label
            Fav.idname = self.idname
            Fav.icon_value = self.icon_value
            Fav.index = len(addon_prefs.global_favs) -1
            Fav.is_preset=self.is_preset
        else:
            newFav = scene.favit.add()
            newFav.label = self.label
            newFav.idname = self.idname
            newFav.icon_value = self.icon_value
            newFav.index = len(scene.favit) -1
            newFav.is_preset=self.is_preset
        
        
        
        return {"FINISHED"}

class BS_OT_Disabled(Operator):
    bl_idname="bs.disabled"
    bl_label="Can\'t find any brush"
    bl_description='Can\'t find any brush'
    
    @classmethod
    def poll(self, context):
        return False
    
    def execute(self, context):
        return {'FINISHED'}

class BS_OT_DeleteFav(Operator):
    bl_idname = "bs.delete_fav"
    bl_label = "Remove from Favourite"
    bl_description = "Remove brush from favorites"

    local_index: IntProperty()
    global_index: IntProperty()
    global_faved: BoolProperty()
    local_faved: BoolProperty()

    def execute(self, context):
        addon_prefs = context.preferences.addons[__name__].preferences
    
        if self.global_index < 0:
            self.global_index = 0
        if self.local_index < 0:
            self.local_index = 0
        
        if self.global_faved:
            addon_prefs.global_favs.remove(self.global_index)
            for i in addon_prefs.global_favs:
                if i.index > self.global_index:
                    i.index = i.index-1
                    if i.index <= 0:
                        i.index=0
        if self.local_faved:
            context.scene.favit.remove(self.local_index)
            for i in context.scene.favit:
                if i.index > self.local_index:
                    i.index = i.index-1
                    if i.index <= 0:
                        i.index=0
        
        return {"FINISHED"}

class BS_OT_show_fav(Menu):
    bl_idname = "TOOLBOX_MT_show_fav"
    bl_label = "Favourites"
    
    
    
    @classmethod
    def poll(self, context):
        space_type=context.space_data.type
        clsic = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
        if clsic == None:
            return False
        if space_type=='SEQUENCE_EDITOR':
            return False
        return True

    def draw(self, context):
        
        space_type=bpy.context.space_data.type
        clsic = ToolSelectPanelHelper._tool_class_from_space_type(space_type)
        addon_prefs = context.preferences.addons[__name__].preferences
        lay = self.layout
        layout=lay.grid_flow(columns=addon_prefs.fav_menu_column,align=True)
        layout.scale_y=1.5
        
        space_type = context.space_data.type
        tool_active_id = getattr(
            ToolSelectPanelHelper._tool_active_from_context(context, space_type),
            "idname", None,
        )
        
        
        
        for item_group in clsic.tools_from_context(context):
            is_active=False
            if type(item_group) is tuple:
                index_current = clsic._tool_group_active.get(item_group[0].idname, 0)
                for sub_item in item_group:
                    ###Global fav#####
                    
                    for m in addon_prefs.global_favs:
                        if sub_item.idname == m.idname:
                            is_active=(sub_item.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                            r=layout.column(align=True)
                            r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                                
                    for m in context.scene.favit:
                        if sub_item.idname == m.idname:
                            is_active=(sub_item.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(sub_item.icon)
                            r=layout.column(align=True)
                            r.operator("wm.tool_set_by_id", text=sub_item.label, icon_value=icon_value,depress=is_active).name=sub_item.idname
                            
            else:
                if item_group is not None:
                    ####global fav######
                    
                    for m in addon_prefs.global_favs:
                        if item_group.idname == m.idname:
                            is_active=(item_group.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                            r=layout.column(align=True)
                            r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     

                    for m in context.scene.favit:
                        if item_group.idname == m.idname:
                            is_active=(item_group.idname == tool_active_id)
                            icon_value = ToolSelectPanelHelper._icon_value_from_icon_handle(item_group.icon)
                            r=layout.column(align=True)
                            r.operator("wm.tool_set_by_id", text=item_group.label, icon_value=icon_value,depress=is_active).name=item_group.idname     
                            
        
        if space_type == 'VIEW_3D':
            
            def preset_favs():
                if brush.name == m.label:
                    icon_value= m.icon_value
                    r=layout.column(align=True)
                    r.operator('bs.set_brush', text=brush.name.title(), icon_value=icon_value).brush_name=m.label
                    
            ####Global fav#####
            
            for m in addon_prefs.global_favs:
                try:
                    if m.is_preset:
                        if m.label in bpy.data.brushes:
                            brush = bpy.data.brushes[m.label]
                            if brush.name == m.label:
                                icon_value= brush.preview.icon_id
                                if context.mode == 'SCULPT':
                                    if brush.use_paint_sculpt:
                                        preset_favs()
                                elif context.mode == 'PAINT_VERTEX':
                                    if brush.use_paint_vertex:
                                        preset_favs()
                                elif context.mode == 'PAINT_WEIGHT':
                                    if brush.use_paint_weight:
                                        preset_favs()
                                elif context.mode == 'PAINT_TEXTURE':
                                    if brush.use_paint_image:
                                        preset_favs()
                                elif context.mode == 'PAINT_GPENCIL':
                                    if brush.use_paint_grease_pencil:
                                        preset_favs()
                                elif context.mode == 'VERTEX_GPENCIL':
                                    if brush.use_vertex_grease_pencil:
                                        preset_favs()
                        else:
                            
                            icon_value= m.icon_value
                            r=layout.column(align=True)
                            r.operator('bs.disabled', text=m.label, icon_value=icon_value)
                except:
                    pass
            
            for m in context.scene.favit:
                try:
                    if m.is_preset:
                        for brush in bpy.data.brushes:
                            if brush.name == m.label:
                                icon_value= brush.preview.icon_id
                                if context.mode == 'SCULPT':
                                    if brush.use_paint_sculpt:
                                        preset_favs()
                                elif context.mode == 'PAINT_VERTEX':
                                    if brush.use_paint_vertex:
                                        preset_favs()
                                elif context.mode == 'PAINT_WEIGHT':
                                    if brush.use_paint_weight:
                                        preset_favs()
                                elif context.mode == 'PAINT_TEXTURE':
                                    if brush.use_paint_image:
                                        preset_favs()
                                elif context.mode == 'PAINT_GPENCIL':
                                    if brush.use_paint_grease_pencil:
                                        preset_favs()
                                elif context.mode == 'VERTEX_GPENCIL':
                                    if brush.use_vertex_grease_pencil:
                                        preset_favs()
                except:
                    pass
                    

    def execute(self, context):
        bpy.ops.wm.call_menu("EXEC_REGION_WIN")
        return {"FINISHED"}

class BsAddonPreferences(AddonPreferences):
    bl_idname = __name__
    
    global_favs: CollectionProperty(type=Favourites)
    
    column_num: IntProperty(
        name='Number of columns',
        description='Number of columns in Toolbox',
        default=4
    )
    fav_column_num: IntProperty(
        name='Number of fav columns',
        description='Number of columns in favourites grid',
        default=6
    )
    fav_menu_column: IntProperty(
        name='Number of columns in fav menu',
        description='Number of columns in favourites menus',
        default=3,
        min=1
    )
    toolbox_width: IntProperty(
        name='Toolbox width',
        description='Width of the toolbox',
        default=700,
        min=100
    )
    
    toolbox_pos: StringProperty(
        default='TR',
    )
    
    save_fav_globally: BoolProperty(
        name='Save fav globally',
        description='If enabled, favouriting a tool will be saved globally and it will be shown in every new blend file',
        default=True
    )
    show_toolbox_button: BoolProperty(
        name='Show Toolbox Button',
        description='If enabled, a Toolbox button will be shown in every editor at top right corner',
        default=False,
        update=update_toolbox_button
    )
    fixed_toolbox: BoolProperty(
        name='Show Toolbox at fixed position',
        description='If enabled, Toolbox fill shown at fixed position',
        default=False,
    )
    
    show_fav_icon: BoolProperty(
        name='Show hearts',
        default=False
    )
    
    show_presets: BoolProperty(
        name='Show Preset Brushes',
        default=False
    )
    show_global_favs: BoolProperty(
        name='Show Global Favourites',
        default=True
    )
    show_sidebar: BoolProperty(
        name='Show sidebar',
        description='Show sidebar menus at the left side of the toolbox',
        default=True
    )
    show_topbar_menus: BoolProperty(
        name='Show top bar menus',
        description='Show menus at the top of the toolbox',
        default=True
    )
    show_searchbar: BoolProperty(
        name='Show searchbar',
        description='Show searchbar at top of toolbox',
        default=True
    )
    show_texture_settings: BoolProperty(
        name='Show Texture Settings',
        default=False,
        description='Show brush texture settings'    
    )
    show_pallete: BoolProperty(
        name='Show Color Pallete',
        default=False,
        description='Show Color Palletes'    
    )
    show_all_brush_settings: BoolProperty(
        name='Show All brush settings',
        default=True,
        description='Show all brush settings in toolbox sidebar'    
    )
    show_extra_menus: BoolProperty(
        name='Show Extra Menus',
        default=False,
        description='Show more menus like Brush option, Texture, Falloff, stroke etc'    
    )
    show_alphabet_filter_menu: BoolProperty(
        name='Show Alphabets',
        default=True,
        description='Show the alphabets used to filter tools'    
    )
    show_ui_buttons: BoolProperty(
        name='Show UI buttons',
        default=True,
        description='Show UI buttons at top right cornder of toolbox'    
    )
    
    keymap_map_type: StringProperty(default='KEYBOARD')
    keymap_type: StringProperty(default='SPACE')
    keymap_value: StringProperty(default='PRESS')
    keymap_any: BoolProperty(default=False)
    keymap_shift: BoolProperty(default=False)
    keymap_alt: BoolProperty(default=False)
    keymap_ctrl: BoolProperty(default=False)
    keymap_cmd: BoolProperty(default=False)
    keymap_repeat: BoolProperty(default=True)
    
    fav_map_type: StringProperty(default='KEYBOARD')
    fav_type: StringProperty(default='V')
    fav_value: StringProperty(default='PRESS')
    fav_any: BoolProperty(default=False)
    fav_shift: BoolProperty(default=False)
    fav_alt: BoolProperty(default=True)
    fav_ctrl: BoolProperty(default=False)
    fav_cmd: BoolProperty(default=False)
    fav_repeat: BoolProperty(default=True)
    
    shortcuts_updated: BoolProperty(default=False)
    
    
    def draw(self,context):
        layout=self.layout
        addon_prefs = context.preferences.addons[__name__].preferences
        
        box = layout.box()
        col = box.column(align=True)
        col.label(text='Favourites settings')
        col.prop(self, 'save_fav_globally')
        r=col.row(align=True)
        r.operator('bs.clear_fav', text='Clear Global Favourites').type='GLOBAL'
        r.operator('bs.clear_fav', text='Clear Local Favourites').type='LOCAL'
        r=col.row(align=True)
        r.operator('bs.export_fav', text='Export Favourites', icon='EXPORT' )
        r.operator('bs.import_fav', text='Import favourites', icon='IMPORT' )
        box = layout.box()
        col = box.column(align=True)
        col.label(text='UI settings')
        col.prop(self, 'column_num')
        col.prop(self, 'fav_column_num')
        col.prop(self, 'fav_menu_column')
        col.prop(self, 'toolbox_width')
        col.prop(context.preferences.view, "color_picker_type")
#        col.prop(self, 'show_toolbox_button')
        col.prop(self, 'show_fav_icon')
        col.prop(self, 'show_presets')
        col.prop(self, 'show_global_favs')
        col.prop(self, 'show_pallete')
        col.prop(self, 'show_sidebar')
        col.prop(self, 'show_all_brush_settings')
        col.prop(self, 'show_topbar_menus')
        col.prop(self, 'show_extra_menus')
        col.prop(self, 'show_alphabet_filter_menu')
        col.prop(self, 'show_ui_buttons')
        if self.show_topbar_menus:
            col.prop(self, 'show_searchbar')
        col.prop(self, 'fixed_toolbox')
        if self.fixed_toolbox:
            
            def depressed(let):
                dep = False
                if addon_prefs.toolbox_pos == let:
                    dep = True
                else:
                    dep = False
                return dep
           
            b = col.box()
            ro=b.row()
            ro.label(text='Toolbox Position: ')
            c=ro.column(align=True)
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('TL')).pos='TL'
            rowi.operator('bs.change_pos', text='', icon='TRIA_UP', depress=depressed('CU')).pos='CU'
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('TR')).pos='TR'
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='TRIA_LEFT', depress=depressed('CL')).pos='CL'
            rowi.operator('bs.change_pos', text='', icon='RADIOBUT_ON', depress=depressed('C')).pos='C'
            rowi.operator('bs.change_pos', text='', icon='TRIA_RIGHT', depress=depressed('CR')).pos='CR'
            rowi=c.row(align=True)
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('BL')).pos='BL'
            rowi.operator('bs.change_pos', text='', icon='TRIA_DOWN', depress=depressed('CD')).pos='CD'
            rowi.operator('bs.change_pos', text='', icon='DOT', depress=depressed('BR')).pos='BR'
        
        box = layout.box()
        col = box.column()
        col.label(text='Shortcuts')
        kc = context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items['bs.show_toolbox']
        km=None
        for c in context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items:
            try:
                if c.properties.name=='TOOLBOX_MT_show_fav':
                    km=c
            except:
                pass
        kc = context.window_manager.keyconfigs.user.keymaps['Window'].keymap_items['bs.show_toolbox']
        draw_kmi(kc, col,0)
        draw_kmi(km, col,0)
        


class BS_OT_ExportFav(Operator, ImportHelper):
    bl_idname = "bs.export_fav"
    bl_label = "Export global favourites"
    bl_description = "Export global favourites to a local file to load it later"

#    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})
    filename_ext = '.json'
    filename: StringProperty()

    def execute(self, context):
        display = "filepath= " + self.filepath
        addon_prefs = context.preferences.addons[__name__].preferences
        data = [
            prop.items()
            for prop in addon_prefs.global_favs
        ]
        
        filename = ''
        
        if self.filepath.endswith("\\"):
            filename=self.filepath+'Toolbox_favourite.json'
        elif self.filepath.endswith(".json"):
            filename=self.filepath
        else:
            filename=self.filepath+".json"
        
        data= json.dumps(data)
        
        with open(filename, 'w') as outfile:
            outfile.write(data + '\n')
        
        self.report({'INFO'}, message='Saved Favourites to ' + filename)
            
        return {"FINISHED"}
    def invoke(self,context,event):
        self.filename='Toolbox_favourites.json'
        wm = context.window_manager.fileselect_add(self)
        return {'RUNNING_MODAL'}


class BS_OT_ImportFav(Operator, ImportHelper):
    bl_idname = "bs.import_fav"
    bl_label = "Import global favourites"
    bl_description = "Import global favourites from a JSON file"

#    filter_glob: StringProperty(default="*.blend", options={"HIDDEN"})

    def execute(self, context):
        addon_prefs = context.preferences.addons[__name__].preferences
        filename = ''
        
        if self.filepath.endswith("\\"):
            self.report({'ERROR'}, message='Couldn\'t locate ' + self.filepath)
            return {'FINISHED'}
        elif self.filepath.endswith(".json"):
            filename=self.filepath
        else:
            self.report({'ERROR'}, message='File should be a JSON file')
            return {'FINISHED'}
        
        with open(filename, 'r') as fp:
            data_file = json.load(fp)
            
        try:
            if addon_prefs.global_favs:
                addon_prefs.global_favs.clear()
            for item in data_file: 
                global_fav = addon_prefs.global_favs.add()
                for key, value in item:
                    if key == 'is_preset':
                        bl = False
                        if value == 1:
                            bl = True
                        global_fav[key] = bl
                    else:
                        global_fav[key] = value
            
                    
            self.report({'INFO'}, message='Imported Global favourites')        
        except:
            self.report({'ERROR'}, message='Couldn\'t import favourites. Something missing in JSON')
            
        return {"FINISHED"}

class BS_OT_ClearFav(Operator):
    bl_idname = "bs.clear_fav"
    bl_label = "Remove favourites"
    bl_description = "Remove favourites"
    
    type: StringProperty()
    
    def execute(self, context):
        if self.type=='GLOBAL':
            addon_prefs = context.preferences.addons[__name__].preferences
            addon_prefs.global_favs.clear()
            self.report({'INFO'}, message='Removed all global favourites')
        else:
            context.scene.favit.clear()
            self.report({'INFO'}, message='Removed all local favourites')

        return {'FINISHED'}
    



class BS_OT_ChangeShortcut(Operator):
    bl_idname = "bs.change_shortcut"
    bl_label = "Change Shortcut"
    bl_description = "Change shortcut"
    
    def execute(self, context):
        bpy.ops.screen.userpref_show('INVOKE_DEFAULT')
        context.preferences.active_section = 'KEYMAP'
        context.window_manager.keyconfigs.user.keymaps['Window'].show_expanded_children=True
        return {'FINISHED'}
    
class BS_OT_ChangeToolboxPosition(Operator):
    bl_idname = "bs.change_pos"
    bl_label = "Toolbox Position"
    bl_description = "Position of toolbox"
    
    pos: StringProperty()
    
    def execute(self, context):
        
        addon_prefs = context.preferences.addons[__name__].preferences
        if self.pos=='C':
            addon_prefs.toolbox_pos = 'C'
        elif self.pos=='CU':
            addon_prefs.toolbox_pos = 'CU'
        elif self.pos=='CD':
            addon_prefs.toolbox_pos = 'CD'
        elif self.pos=='CL':
            addon_prefs.toolbox_pos = 'CL'
        elif self.pos=='CR':
            addon_prefs.toolbox_pos = 'CR'
        elif self.pos=='TL':
            addon_prefs.toolbox_pos = 'TL'
        elif self.pos=='TR':
            addon_prefs.toolbox_pos = 'TR'
        elif self.pos=='BL':
            addon_prefs.toolbox_pos = 'BL'
        elif self.pos=='BR':
            addon_prefs.toolbox_pos = 'BR'
        return {'FINISHED'}
    
class _draw_tool_settings_context_mode:
    @staticmethod
    def SCULPT(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        paint = context.tool_settings.sculpt
        brush = paint.brush
        if brush is None:
            return False

        tool_settings = context.tool_settings
        capabilities = brush.sculpt_capabilities
        addon_prefs = context.preferences.addons[__name__].preferences
        ups = tool_settings.unified_paint_settings

        size = "size"
        size_owner = ups if ups.use_unified_size else brush
        
        try:
            if capabilities.has_color:
                split = layout.split(factor=0.1)
                UnifiedPaintPanel.prop_unified_color(split, context, brush, "color", text="")
                UnifiedPaintPanel.prop_unified_color_picker(split, context, brush, "color", value_slider=True)
                layout.prop(brush, "blend", text="", expand=False)
            else:
                layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=False)
        except:
            layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=False)
        
        if addon_prefs.show_all_brush_settings:
            settings = UnifiedPaintPanel.paint_settings(context)
            brush = settings.brush

            brush_settings(layout, context, brush, False)
        else:
            if size_owner.use_locked_size == 'SCENE':
                size = "unprojected_radius"

            UnifiedPaintPanel.prop_unified(
                layout,
                context,
                brush,
                size,
                pressure_name="use_pressure_size",
                unified_name="use_unified_size",
                text="Radius",
                slider=True,
                header=False
            )

            # strength, use_strength_pressure
            pressure_name = "use_pressure_strength" if capabilities.has_strength_pressure else None
            UnifiedPaintPanel.prop_unified(
                layout,
                context,
                brush,
                "strength",
                pressure_name=pressure_name,
                unified_name="use_unified_strength",
                text="Strength",
                header=False
            )

            # direction
            if not capabilities.has_direction:
                layout.row().prop(brush, "direction", expand=True)
            if capabilities.has_auto_smooth:
                layout.prop(brush, "auto_smooth_factor", slider=True)

            if capabilities.has_normal_weight:
                layout.prop(brush, "normal_weight", slider=True)

            if capabilities.has_pinch_factor:
                text = "Pinch"
                if brush.sculpt_tool in {'BLOB', 'SNAKE_HOOK'}:
                    text = "Magnify"
                layout.prop(brush, "crease_pinch_factor", slider=True, text=text)

            if capabilities.has_rake_factor:
                layout.prop(brush, "rake_factor", slider=True)

            if capabilities.has_plane_offset:
                layout.prop(brush, "plane_offset", slider=True)
                layout.prop(brush, "plane_trim", slider=True, text="Distance")

            if capabilities.has_height:
                layout.prop(brush, "height", slider=True, text="Height")

        row=layout.row(align=True)
        row.template_ID(brush, "texture",live_icon=True)
        
        tex=tool_settings.sculpt.brush.texture
        if tex is None:
            row.operator('bs.add_texture', text='New Texture')
        else:
            if tex.image is None:
                layout.template_image(tex, "image", tex.image_user)
            else:
                row.operator('wm.call_panel', text='', icon='SETTINGS').name='VIEW3D_PT_tools_brush_texture'
    #        row.operator('wm.call_panel', text='Texture settings', icon='TEXTURE').name='VIEW3D_PT_tools_brush_texture'
        
        return True

    @staticmethod
    def PAINT_TEXTURE(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        paint = context.tool_settings.image_paint
        

        brush = paint.brush
        if brush is None:
            return False

        tool_settings = context.tool_settings
        capabilities = brush.image_paint_capabilities

        try:
            if capabilities.has_color:
                split = layout.split(factor=0.1)
                UnifiedPaintPanel.prop_unified_color(split, context, brush, "color", text="")
                UnifiedPaintPanel.prop_unified_color_picker(split, context, brush, "color", value_slider=True)
                layout.prop(brush, "blend", text="")
            else:
                layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=True)
        except:
            layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=True)
        if capabilities.has_radius:
            UnifiedPaintPanel.prop_unified(
                layout,
                context,
                brush,
                "size",
                unified_name="use_unified_size",
                pressure_name="use_pressure_size",
                slider=True,
            )
            UnifiedPaintPanel.prop_unified(
                layout,
                context,
                brush,
                "strength",
                unified_name="use_unified_strength",
                pressure_name="use_pressure_strength",
                slider=True,
            )
        
        row=layout.row(align=True)
        row.template_ID(brush, "texture",live_icon=True)
    
        
        tex=tool_settings.image_paint.brush.texture
        if tex is None:
            row.operator('bs.add_texture', text='New Texture')
        else:
            if tex.image is None:
                layout.template_image(tex, "image", tex.image_user)
            else:
                row.operator('wm.call_panel', text='', icon='SETTINGS').name='VIEW3D_PT_tools_brush_texture'

        return True

    @staticmethod
    def PAINT_VERTEX(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        tool_settings = context.tool_settings
        paint = context.tool_settings.vertex_paint
        

        brush = paint.brush
        if brush is None:
            return False

        capabilities = brush.vertex_paint_capabilities

        try:
            if capabilities.has_color:
                split = layout.split(factor=0.1)
                UnifiedPaintPanel.prop_unified_color(split, context, brush, "color", text="")
                UnifiedPaintPanel.prop_unified_color_picker(split, context, brush, "color", value_slider=True)
                layout.prop(brush, "blend", text="")
            else:
                layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=True)
        except:
            layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=True)
            
        UnifiedPaintPanel.prop_unified(
            layout,
            context,
            brush,
            "size",
            unified_name="use_unified_size",
            pressure_name="use_pressure_size",
            slider=True,
        )
        UnifiedPaintPanel.prop_unified(
            layout,
            context,
            brush,
            "strength",
            unified_name="use_unified_strength",
            pressure_name="use_pressure_strength",
            slider=True,
        )
        row=layout.row(align=True)
        row.template_ID(brush, "texture",live_icon=True)
        
        tex=tool_settings.vertex_paint.brush.texture
        if tex is None:
            row.operator('bs.add_texture', text='New Texture')
        else:
            if tex.image is None:
                layout.template_image(tex, "image", tex.image_user)
            else:
                row.operator('wm.call_panel', text='', icon='SETTINGS').name='VIEW3D_PT_tools_brush_texture'

        return True

    @staticmethod
    def PAINT_WEIGHT(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        paint = context.tool_settings.weight_paint
        layout.template_ID_preview(paint, "brush", rows=3, cols=8, hide_buttons=True)
        brush = paint.brush
        if brush is None:
            return False

        capabilities = brush.weight_paint_capabilities
        if capabilities.has_weight:
            UnifiedPaintPanel.prop_unified(
                layout,
                context,
                brush,
                "weight",
                unified_name="use_unified_weight",
                slider=True,
                header=True
            )

        UnifiedPaintPanel.prop_unified(
            layout,
            context,
            brush,
            "size",
            pressure_name="use_pressure_size",
            unified_name="use_unified_size",
            slider=True,
            text="Radius",
            header=True
        )
        UnifiedPaintPanel.prop_unified(
            layout,
            context,
            brush,
            "strength",
            pressure_name="use_pressure_strength",
            unified_name="use_unified_strength",
            header=True
        )

        return True

    @staticmethod
    def PAINT_GPENCIL(context, layout, tool):
        addon_prefs = context.preferences.addons[__name__].preferences
        if tool is None:
            return False

        if tool.idname == "builtin.cutter":
            row = layout.row(align=True)
            row.prop(context.tool_settings.gpencil_sculpt, "intersection_threshold")
            return False
        elif not tool.has_datablock:
            return False

        paint = context.tool_settings.gpencil_paint
        brush = paint.brush
        if brush is None:
            return False

        ts = context.tool_settings
        settings = ts.gpencil_paint
        brush = settings.brush
        gp_settings = brush.gpencil_settings
        is_pin_vertex = gp_settings.brush_draw_mode == 'VERTEXCOLOR'
        is_vertex = settings.color_mode == 'VERTEXCOLOR' or brush.gpencil_tool == 'TINT' or is_pin_vertex
        coli=layout.column()
        sub_row = coli.row(align=True)
        sub_row.enabled = not gp_settings.pin_draw_mode
        sub_row.label(text='Color mode:  ')
        sub_row.prop_enum(settings, "color_mode", 'MATERIAL', text="", icon='MATERIAL')
        sub_row.prop_enum(settings, "color_mode", 'VERTEXCOLOR', text="", icon='VPAINT_HLT')
        if brush.gpencil_tool not in {'ERASE', 'CUTTER', 'EYEDROPPER'} and is_vertex:
            split = coli.split(factor=0.1)
            split.prop(brush, "color", text="")
            split.template_color_picker(brush, "color", value_slider=True)

            col = coli.column()
            col.separator()
            col.prop_menu_enum(gp_settings, "vertex_mode", text="Mode")
            if addon_prefs.show_pallete:
                col.separator()
                col.template_ID(settings, "palette", new="palette.new")
                if settings.palette:
                    col.template_palette(settings, "palette", color=True)

        if brush.gpencil_tool not in {'FILL', 'CUTTER'}:
            coli.prop(brush, "size", slider=True)
        if brush.gpencil_tool not in {'ERASE', 'FILL', 'CUTTER'}:
            coli.prop(gp_settings, "pen_strength")

        # Layers
        gpd = context.active_gpencil_layer
        coli.label(text='Active Layer')
        if gpd is None:
            layout.operator("gpencil.layer_add", text="New Layer")
        else:
            r=coli.row(align=True)
            r.operator('wm.call_panel', text=gpd.info, icon='GREASEPENCIL').name='TOPBAR_PT_gpencil_layers'
            r.operator("gpencil.layer_add", icon='ADD', text="")
            r.operator("gpencil.layer_remove", icon='REMOVE', text="")
        # Material
        if not is_vertex:
            gp_settings=context.tool_settings.gpencil_paint.brush.gpencil_settings
            ma = gp_settings.material

            row = layout.row(align=True)
            if not gp_settings.use_material_pin:
                ma = context.object.active_material
            icon_id = 0
            txt_ma=''
            
            if ma:
                icon_id = ma.id_data.preview.icon_id
                txt_ma = ma.name
                maxw = 25
                if len(txt_ma) > maxw:
                    txt_ma = txt_ma[:maxw - 5] + '..' + txt_ma[-3:]
            else:
                txt_ma = ""
            sub = row.row(align=True)
            sub.ui_units_x = 8
#            sub.operator('wm.call_panel', text=txt_ma, icon_value=icon_id,).name='TOPBAR_PT_gpencil_materials'
            sub.prop(gp_settings, "use_material_pin", text="")
#            layout.template_ID(context.object, "active_material", new="material.new", live_icon=True)
            
        return True

    @staticmethod
    def SCULPT_GPENCIL(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False
        paint = context.tool_settings.gpencil_sculpt_paint
        brush = paint.brush

        from bl_ui.properties_paint_common import (
            brush_basic_gpencil_sculpt_settings,
        )
        brush_basic_gpencil_sculpt_settings(layout, context, brush, compact=True)
        return True

    @staticmethod
    def WEIGHT_GPENCIL(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False
        paint = context.tool_settings.gpencil_weight_paint
        brush = paint.brush

        from bl_ui.properties_paint_common import (
            brush_basic_gpencil_weight_settings,
        )
        brush_basic_gpencil_weight_settings(layout, context, brush, compact=True)

        return True

    @staticmethod
    def VERTEX_GPENCIL(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        ts = context.tool_settings
        settings = ts.gpencil_vertex_paint
        brush = settings.brush
        gp_settings = brush.gpencil_settings
        gpencil_paint = ts.gpencil_vertex_paint

        col = layout.column()

        if brush.gpencil_vertex_tool in {'DRAW', 'REPLACE'}:
            split = layout.split(factor=0.1)
            split.prop(brush, "color", text="")
            split.template_color_picker(brush, "color", value_slider=True)

            col = layout.column()
            col.separator()
            col.prop_menu_enum(gp_settings, "vertex_mode", text="Mode")
            col.separator()
        else:
            col.template_ID_preview(gpencil_paint, "brush", new="brush.add_gpencil", rows=3, cols=8)

        row = col.row(align=True)
        row.prop(brush, "size", text="Radius")
        row.prop(gp_settings, "use_pressure", text="", icon='STYLUS_PRESSURE')

        if brush.gpencil_vertex_tool in {'DRAW', 'BLUR', 'SMEAR'}:
            row = layout.row(align=True)
            row.prop(gp_settings, "pen_strength", slider=True)
            row.prop(gp_settings, "use_strength_pressure", text="", icon='STYLUS_PRESSURE')

        # Layers
        draw_gpencil_layer_active(context, layout)

        return True

    @staticmethod
    def PARTICLE(context, layout, tool):
        if (tool is None) or (not tool.has_datablock):
            return False

        # See: 'VIEW3D_PT_tools_brush', basically a duplicate
        settings = context.tool_settings.particle_edit
        brush = settings.brush
        tool = settings.tool
        if tool == 'NONE':
            return False

        layout.prop(brush, "size", slider=True)
        if tool == 'ADD':
            layout.prop(brush, "count")

            layout.prop(settings, "use_default_interpolate")
            layout.prop(brush, "steps", slider=True)
            layout.prop(settings, "default_key_count", slider=True)
        else:
            layout.prop(brush, "strength", slider=True)

            if tool == 'LENGTH':
                layout.row().prop(brush, "length_mode", expand=True)
            elif tool == 'PUFF':
                layout.row().prop(brush, "puff_mode", expand=True)
                layout.prop(brush, "use_puff_volume")
            elif tool == 'COMB':
                row = layout.row()
                row.active = settings.is_editable
                row.prop(settings, "use_emitter_deflect", text="Deflect Emitter")
                sub = row.row(align=True)
                sub.active = settings.use_emitter_deflect
                sub.prop(settings, "emitter_distance", text="Distance")

        return True
    
class BS_OT_add_texture(Operator):
    bl_idname='bs.add_texture'
    bl_label='New Texture'
    bl_description='Create new brush image texture'
    
    def execute(self, context):
        tex=bpy.data.textures.new('Texture','IMAGE')
        if context.mode=='SCULPT':
            context.tool_settings.sculpt.brush.texture=tex
        elif context.mode=='PAINT_VERTEX':
            context.tool_settings.vertex_paint.brush.texture=tex
        elif context.mode=='PAINT_TEXTURE':
            context.tool_settings.image_paint.brush.texture=tex
        return {'FINISHED'}

    
classes= (
    BrushLetters,
    Favourites,
    BS_OT_show_brushes,
    BS_OT_AddFav,
    BS_OT_DeleteFav,
    BS_UL_FavList,
    BS_OT_SetBrush,
    BS_OT_ShowSettings,
    BS_OT_show_fav,
    BsAddonPreferences,
    BS_OT_Disabled,
    BS_OT_ExportFav,
    BS_OT_ImportFav,
    BS_OT_ClearFav,
    BS_OT_ChangeShortcut,
    BS_OT_ChangeToolboxPosition,
    BS_OT_add_texture,
)
def register():
    
    wm = bpy.context.window_manager
    kc = wm.keyconfigs.addon

#    addon_prefs = bpy.context.preferences.addons['quick_toolbox'].preferences

    for km, kmi, kmk in addon_keymaps:
        km.keymap_items.remove(kmi)
        km.keymap_items.remove(kmk)
    addon_keymaps.clear()
    
    if kc:
        km = kc.keymaps.new(name="Window")
        kmi= km.keymap_items.new(
            "wm.call_menu", type='V', value='PRESS', alt=True
        )
        kmi.properties.name='TOOLBOX_MT_show_fav'
        kmk = km.keymap_items.new(
            "bs.show_toolbox", type='SPACE', value='PRESS'
        )
        addon_keymaps.append((km, kmi,kmk))
    
    
#    add_hotkey()
            
    for clss in classes:
        bpy.utils.register_class(clss)
            
    bpy.types.Scene.brush_letters = PointerProperty(type=BrushLetters)
    bpy.types.Scene.favit = CollectionProperty(type=Favourites)
#        
#    bpy.types.VIEW3D_HT_header.append(bs_header_button)
#    bpy.types.IMAGE_HT_header.append(bs_header_button)
#    bpy.types.NODE_HT_header.append(bs_header_button)
#    bpy.types.SEQUENCER_HT_header.append(bs_header_button)
#    wm.keyconfigs['blender'].preferences.spacebar_action='TOOL'
    
    
    
#    bpy.types.Scene.fav_index = IntProperty(
#        name="fav name", description="fav", default=0
#    )
    
    
    

def unregister():
    for km, kmi, kmk in addon_keymaps:
        km.keymap_items.remove(kmi)
        km.keymap_items.remove(kmk)
    addon_keymaps.clear()
    for i in classes:
        bpy.utils.unregister_class(i)
    del bpy.types.Scene.brush_letters
    del bpy.types.Scene.favit
#    del bpy.types.Scene.fav_index
#    addon_prefs = bpy.context.preferences.addons[__name__].preferences
#    if addon_prefs.show_toolbox_button:
#    bpy.types.VIEW3D_HT_header.remove(bs_header_button)
#    bpy.types.IMAGE_HT_header.remove(bs_header_button)
#    bpy.types.NODE_HT_header.remove(bs_header_button)
#    bpy.types.SEQUENCER_HT_header.remove(bs_header_button)


if __name__ == "__main__":
    register()
